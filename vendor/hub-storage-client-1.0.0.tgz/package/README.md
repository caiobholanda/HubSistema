# @hub/storage-client

Cliente de object storage S3-compatível. Não conhece SQLite, JSON, backup ou aplicações — apenas operações de armazenamento.

## Escopo

- Sabe falar com qualquer endpoint S3-compatível (Tigris, Cloudflare R2, AWS S3) através de uma única classe, `S3CompatibleProvider`, parametrizada por configuração.
- Não sabe o que é "backup", "restore", "retenção" ou "aplicação" — isso é responsabilidade de `@hub/backup-core`.
- Azure Blob (protocolo diferente de S3) exigiria uma classe adapter própria implementando `IStorageProvider` — fora do escopo desta Sprint.

## API

Ver [`docs/StorageProvider.md`](../../docs/StorageProvider.md) na raiz do repositório para a referência completa do contrato `IStorageProvider` e da configuração do `S3CompatibleProvider`.

## Status

Sprint 1 — implementado e utilizável isoladamente (upload/download/delete/list/copy/move/getSignedUrl/health). Sprint 2 adicionou `loadS3ConfigFromEnv()`, lendo os Secrets `S3_ENDPOINT`/`S3_REGION`/`S3_BUCKET`/`S3_ACCESS_KEY_ID`/`S3_SECRET_ACCESS_KEY` do ambiente (Fly.io em produção, `.env` local para validação manual) — conectado e validado contra o bucket Tigris real (`hub-prod-backups`). Ainda não integrado a nenhuma aplicação do HUB nem a nenhum job/agendador.
