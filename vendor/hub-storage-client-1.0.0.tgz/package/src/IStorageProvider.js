import { NotImplementedError } from './errors.js';

/**
 * @typedef {Object} StorageObjectMeta
 * @property {string} key
 * @property {number} size
 * @property {Date} lastModified
 */

/**
 * @typedef {Object} HealthStatus
 * @property {boolean} healthy
 * @property {number} latencyMs
 * @property {string} bucket
 * @property {string|undefined} endpoint
 * @property {string} checkedAt - ISO-8601
 * @property {string} [note]
 * @property {string} [error]
 */

/**
 * Contrato comum a todo provider de object storage.
 *
 * Não referencia nenhum provider concreto (S3, Tigris, R2, Azure) nem qualquer
 * conceito de aplicação ou backup — apenas operações de armazenamento. Novos
 * providers (ex.: Azure Blob) implementam esta classe sem exigir mudança em
 * nenhum consumidor (Open/Closed Principle).
 *
 * @interface
 */
export class IStorageProvider {
  /**
   * Streaming real (Sprint 4.1, via @aws-sdk/lib-storage na implementação
   * S3-compatível) — não bufferiza o corpo inteiro em memória antes de
   * enviar. Seguro para arquivos grandes. Sprint 3A chegou a bufferizar
   * tudo como workaround de um erro real contra o Tigris; a causa raiz foi
   * corrigida com a ferramenta certa (upload multipart-capable), não
   * contornada.
   *
   * @param {string} key
   * @param {import('stream').Readable} body
   * @param {Record<string,string>} [meta]
   * @returns {Promise<void>}
   */
  async upload(key, body, meta) {
    throw new NotImplementedError('upload');
  }

  /**
   * @param {string} key
   * @returns {Promise<import('stream').Readable>}
   */
  async download(key) {
    throw new NotImplementedError('download');
  }

  /**
   * @param {string} key
   * @returns {Promise<void>}
   */
  async delete(key) {
    throw new NotImplementedError('delete');
  }

  /**
   * Deleção em lote — chamada única ao provider em vez de N chamadas sequenciais.
   * @param {string[]} keys
   * @returns {Promise<void>}
   */
  async deleteBatch(keys) {
    throw new NotImplementedError('deleteBatch');
  }

  /**
   * @param {string} key
   * @returns {Promise<boolean>}
   */
  async exists(key) {
    throw new NotImplementedError('exists');
  }

  /**
   * Paginado — nunca carrega a listagem inteira em memória de uma vez.
   * @param {string} prefix
   * @returns {AsyncIterable<StorageObjectMeta>}
   */
  list(prefix) {
    throw new NotImplementedError('list');
  }

  /**
   * @param {string} sourceKey
   * @param {string} destKey
   * @returns {Promise<void>}
   */
  async copy(sourceKey, destKey) {
    throw new NotImplementedError('copy');
  }

  /**
   * Não é atômico (implementado como copy + delete por baixo dos panos nos
   * providers S3-compatíveis). A origem só é apagada após a cópia ser
   * confirmada.
   * @param {string} sourceKey
   * @param {string} destKey
   * @returns {Promise<void>}
   */
  async move(sourceKey, destKey) {
    throw new NotImplementedError('move');
  }

  /**
   * @param {string} key
   * @param {number} expiresInSeconds
   * @returns {Promise<string>}
   */
  async getSignedUrl(key, expiresInSeconds) {
    throw new NotImplementedError('getSignedUrl');
  }

  /**
   * Verifica conectividade, autenticação e permissão de leitura/listagem,
   * sem gravar nenhum objeto. Não é capaz de confirmar permissão de escrita
   * sem escrever — essa limitação deve ser documentada por quem consome o
   * resultado, não inferida silenciosamente como "tudo ok".
   * @returns {Promise<HealthStatus>}
   */
  async health() {
    throw new NotImplementedError('health');
  }

  /**
   * API INTERNA — exclusiva para adapters que precisam repassar credenciais
   * reais a um processo externo que não fala IStorageProvider (ex.: o
   * binário `litestream`, via SqliteLitestreamAdapter). NUNCA deve ser
   * chamado por uma aplicação consumidora do hub-sdk nem ter seu retorno
   * logado/serializado deliberadamente — o objeto retornado (`RawConnectionConfig`)
   * se autoprotege contra `console.log`/`JSON.stringify` acidental (retorna
   * uma visão redigida nesses casos), mas isso não é uma licença para expor
   * os valores reais de propósito.
   * @returns {import('./RawConnectionConfig.js').RawConnectionConfig}
   */
  getRawConnectionConfig() {
    throw new NotImplementedError('getRawConnectionConfig');
  }
}
