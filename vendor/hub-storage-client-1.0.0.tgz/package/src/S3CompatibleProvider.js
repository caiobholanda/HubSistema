import {
  S3Client,
  GetObjectCommand,
  DeleteObjectCommand,
  DeleteObjectsCommand,
  HeadObjectCommand,
  CopyObjectCommand,
  ListObjectsV2Command,
} from '@aws-sdk/client-s3';
import { Upload } from '@aws-sdk/lib-storage';
import { getSignedUrl as presignUrl } from '@aws-sdk/s3-request-presigner';
import { IStorageProvider } from './IStorageProvider.js';
import { ObjectNotFoundError, ProviderAuthError, ProviderTransientError } from './errors.js';
import { resolveProviderConfig } from './config.js';
import { RawConnectionConfig } from './RawConnectionConfig.js';

/**
 * Único provider concreto para toda a família S3-compatível (Tigris,
 * Cloudflare R2, AWS S3). A diferença entre eles é só configuração
 * (endpoint/region/forcePathStyle via preset — ver config.js), nunca uma
 * classe própria. Azure Blob, por não falar o protocolo S3, exigiria uma
 * classe adapter separada implementando o mesmo IStorageProvider — não
 * criada nesta Sprint.
 */
export class S3CompatibleProvider extends IStorageProvider {
  constructor(rawConfig) {
    super();
    this.config = resolveProviderConfig(rawConfig);
    this.client = new S3Client({
      endpoint: this.config.endpoint,
      region: this.config.region,
      forcePathStyle: this.config.forcePathStyle,
      credentials: {
        accessKeyId: this.config.accessKeyId,
        secretAccessKey: this.config.secretAccessKey,
      },
      maxAttempts: this.config.maxRetries,
      requestHandler: { requestTimeout: this.config.timeoutMs },
    });
  }

  async upload(key, body, meta = {}) {
    try {
      // Sprint 3A bufferizava o corpo inteiro antes de enviar, para contornar
      // um erro real contra o Tigris (`x-amz-decoded-content-length` inválido
      // quando o SDK não sabe o tamanho total de um Readable). @aws-sdk/lib-storage
      // é a ferramenta correta para isso: decide sozinha entre PUT simples e
      // multipart, e sabe lidar com stream de tamanho desconhecido sem
      // bufferizar o conteúdo inteiro em memória — streaming de verdade
      // (Sprint 4.1). Reconfirmar contra o Tigris real na homologação (4.4).
      const upload = new Upload({
        client: this.client,
        params: { Bucket: this.config.bucket, Key: key, Body: body, Metadata: meta },
      });
      await upload.done();
    } catch (err) {
      throw translateError(err, key);
    }
  }

  async download(key) {
    try {
      const result = await this.client.send(
        new GetObjectCommand({ Bucket: this.config.bucket, Key: key })
      );
      return result.Body;
    } catch (err) {
      throw translateError(err, key);
    }
  }

  async delete(key) {
    try {
      await this.client.send(new DeleteObjectCommand({ Bucket: this.config.bucket, Key: key }));
    } catch (err) {
      throw translateError(err, key);
    }
  }

  async deleteBatch(keys) {
    if (keys.length === 0) return;
    try {
      await this.client.send(
        new DeleteObjectsCommand({
          Bucket: this.config.bucket,
          Delete: { Objects: keys.map((Key) => ({ Key })) },
        })
      );
    } catch (err) {
      throw translateError(err);
    }
  }

  async exists(key) {
    try {
      await this.client.send(new HeadObjectCommand({ Bucket: this.config.bucket, Key: key }));
      return true;
    } catch (err) {
      if (isNotFound(err)) return false;
      throw translateError(err, key);
    }
  }

  async *list(prefix) {
    let continuationToken;
    do {
      let page;
      try {
        page = await this.client.send(
          new ListObjectsV2Command({
            Bucket: this.config.bucket,
            Prefix: prefix,
            ContinuationToken: continuationToken,
          })
        );
      } catch (err) {
        throw translateError(err);
      }
      for (const obj of page.Contents ?? []) {
        yield { key: obj.Key, size: obj.Size, lastModified: obj.LastModified };
      }
      continuationToken = page.IsTruncated ? page.NextContinuationToken : undefined;
    } while (continuationToken);
  }

  async copy(sourceKey, destKey) {
    try {
      await this.client.send(
        new CopyObjectCommand({
          Bucket: this.config.bucket,
          CopySource: `${this.config.bucket}/${sourceKey}`,
          Key: destKey,
        })
      );
    } catch (err) {
      throw translateError(err, sourceKey);
    }
  }

  async move(sourceKey, destKey) {
    await this.copy(sourceKey, destKey);
    // só apaga a origem depois da cópia confirmada — move não é atômico
    await this.delete(sourceKey);
  }

  async getSignedUrl(key, expiresInSeconds) {
    try {
      return await presignUrl(this.client, new GetObjectCommand({ Bucket: this.config.bucket, Key: key }), {
        expiresIn: expiresInSeconds,
      });
    } catch (err) {
      throw translateError(err, key);
    }
  }

  async health() {
    const start = Date.now();
    try {
      await this.client.send(new ListObjectsV2Command({ Bucket: this.config.bucket, MaxKeys: 1 }));
      return {
        healthy: true,
        latencyMs: Date.now() - start,
        bucket: this.config.bucket,
        endpoint: this.config.endpoint,
        checkedAt: new Date().toISOString(),
        note:
          'Verifica conectividade, autenticação e permissão de leitura/listagem. ' +
          'Não verifica permissão de escrita (nenhum objeto é gravado por este check).',
      };
    } catch (err) {
      const translated = translateError(err);
      return {
        healthy: false,
        latencyMs: Date.now() - start,
        bucket: this.config.bucket,
        endpoint: this.config.endpoint,
        checkedAt: new Date().toISOString(),
        error: translated.message,
      };
    }
  }

  getRawConnectionConfig() {
    return new RawConnectionConfig({
      endpoint: this.config.endpoint,
      region: this.config.region,
      bucket: this.config.bucket,
      accessKeyId: this.config.accessKeyId,
      secretAccessKey: this.config.secretAccessKey,
      forcePathStyle: this.config.forcePathStyle,
    });
  }
}

function isNotFound(err) {
  return (
    err?.$metadata?.httpStatusCode === 404 || err?.name === 'NotFound' || err?.name === 'NoSuchKey'
  );
}

function translateError(err, key) {
  if (isNotFound(err)) return new ObjectNotFoundError(key ?? '(desconhecido)');
  const status = err?.$metadata?.httpStatusCode;
  if (status === 401 || status === 403) {
    return new ProviderAuthError(err.message ?? 'Falha de autenticação/permissão no provider', err);
  }
  if (!status || status >= 500 || err?.name === 'TimeoutError') {
    return new ProviderTransientError(err.message ?? 'Erro transitório no provider', err);
  }
  return err;
}
