import util from 'node:util';

const REDACTED = '[REDACTED]';

/**
 * Portador de credenciais cruas — API INTERNA, retornada exclusivamente por
 * `IStorageProvider#getRawConnectionConfig()`. Existe apenas para adapters
 * que precisam entregar credenciais reais a um processo externo que não
 * fala o contrato IStorageProvider (ex.: o binário `litestream`, consumido
 * pelo SqliteLitestreamAdapter — ver Sprint 4.2). Nunca deve ser usado por
 * uma aplicação consumidora do hub-sdk.
 *
 * Os valores reais continuam acessíveis por propriedade (`config.secretAccessKey`)
 * porque esse é o uso legítimo do objeto. O que este objeto evita é o
 * vazamento ACIDENTAL: `JSON.stringify(config)` e `console.log(config)`
 * (que por baixo usa `util.inspect`) retornam uma visão redigida em vez do
 * segredo real. Isso não substitui a disciplina de quem consome este
 * método — apenas reduz o dano de um `console.log` esquecido durante debug.
 */
export class RawConnectionConfig {
  constructor({ endpoint, region, bucket, accessKeyId, secretAccessKey, forcePathStyle }) {
    this.endpoint = endpoint;
    this.region = region;
    this.bucket = bucket;
    this.accessKeyId = accessKeyId;
    this.secretAccessKey = secretAccessKey;
    this.forcePathStyle = forcePathStyle;
  }

  toJSON() {
    return redactedView(this);
  }

  [util.inspect.custom]() {
    return redactedView(this);
  }
}

function redactedView(config) {
  return {
    endpoint: config.endpoint,
    region: config.region,
    bucket: config.bucket,
    accessKeyId: maskTail(config.accessKeyId),
    secretAccessKey: REDACTED,
    forcePathStyle: config.forcePathStyle,
  };
}

/** Mantém só os últimos 4 caracteres — útil para identificar qual credencial está em uso sem expor o valor. */
function maskTail(value) {
  if (!value || typeof value !== 'string') return REDACTED;
  if (value.length <= 4) return REDACTED;
  return `***${value.slice(-4)}`;
}
