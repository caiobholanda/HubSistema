/** Método do contrato IStorageProvider chamado sem implementação concreta. */
export class NotImplementedError extends Error {
  constructor(method) {
    super(`${method}() não implementado por este provider`);
    this.name = 'NotImplementedError';
  }
}

/** Objeto não encontrado no bucket. */
export class ObjectNotFoundError extends Error {
  constructor(key) {
    super(`Objeto não encontrado: ${key}`);
    this.name = 'ObjectNotFoundError';
    this.key = key;
  }
}

/** Falha de autenticação ou permissão (HTTP 401/403 do provider). */
export class ProviderAuthError extends Error {
  constructor(message, cause) {
    super(message);
    this.name = 'ProviderAuthError';
    this.cause = cause;
    this.retryable = false;
  }
}

/** Erro transitório (timeout, 5xx, rede) — seguro para retry. */
export class ProviderTransientError extends Error {
  constructor(message, cause) {
    super(message);
    this.name = 'ProviderTransientError';
    this.cause = cause;
    this.retryable = true;
  }
}
