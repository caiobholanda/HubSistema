/**
 * Presets por provider — apenas os valores que diferem entre eles.
 * Nenhuma classe própria por provider: toda a variação vive aqui, como dados,
 * não como código. Adicionar um novo preset S3-compatível não exige tocar em
 * S3CompatibleProvider.
 */
export const PROVIDER_PRESETS = {
  tigris: {
    endpoint: 'https://fly.storage.tigris.dev',
    region: 'auto',
    forcePathStyle: false,
  },
  r2: {
    // endpoint é específico da conta Cloudflare (`https://<account-id>.r2.cloudflarestorage.com`)
    // e deve ser informado explicitamente na configuração — não há default genérico.
    region: 'auto',
    forcePathStyle: false,
  },
  'aws-s3': {
    // endpoint fica a cargo do SDK (endpoint regional padrão da AWS); region é obrigatório.
    forcePathStyle: false,
  },
};

const REQUIRED_FIELDS = ['bucket', 'accessKeyId', 'secretAccessKey', 'region'];

/**
 * Resolve a configuração final do provider combinando entrada explícita com o
 * preset nomeado (`preset`), e valida os campos obrigatórios.
 *
 * @param {{
 *   preset?: 'tigris'|'r2'|'aws-s3',
 *   endpoint?: string,
 *   region?: string,
 *   forcePathStyle?: boolean,
 *   bucket: string,
 *   accessKeyId: string,
 *   secretAccessKey: string,
 *   timeoutMs?: number,
 *   maxRetries?: number,
 * }} input
 */
export function resolveProviderConfig(input) {
  const preset = PROVIDER_PRESETS[input.preset] ?? {};

  const config = {
    preset: input.preset ?? 'custom',
    endpoint: input.endpoint ?? preset.endpoint,
    region: input.region ?? preset.region,
    forcePathStyle: input.forcePathStyle ?? preset.forcePathStyle ?? false,
    bucket: input.bucket,
    accessKeyId: input.accessKeyId,
    secretAccessKey: input.secretAccessKey,
    timeoutMs: input.timeoutMs ?? 10_000,
    maxRetries: input.maxRetries ?? 3,
  };

  const missing = REQUIRED_FIELDS.filter((field) => !config[field]);
  if (missing.length > 0) {
    throw new Error(
      `Configuração de storage inválida (preset="${config.preset}"): campos ausentes: ${missing.join(', ')}`
    );
  }

  return config;
}
