/**
 * Resolve a configuração de conexão do storage-client a partir dos Secrets
 * do Fly.io (ou de um .env local, para execução manual): S3_ENDPOINT,
 * S3_REGION, S3_BUCKET, S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY.
 *
 * Nenhum valor tem default hardcoded — os cinco vêm sempre do ambiente,
 * mesmo quando o provedor de fato é Tigris (que teria um endpoint default
 * via preset). Isso mantém a fonte de verdade única: o que está cadastrado
 * como Secret, não um valor implícito no código.
 *
 * Função pura: recebe `env` como parâmetro (default `process.env`) para ser
 * testável sem depender de variáveis de ambiente reais.
 */

const REQUIRED = ['S3_ENDPOINT', 'S3_REGION', 'S3_BUCKET', 'S3_ACCESS_KEY_ID', 'S3_SECRET_ACCESS_KEY'];

/**
 * @param {NodeJS.ProcessEnv} [env]
 * @returns {{ endpoint: string, region: string, bucket: string, accessKeyId: string, secretAccessKey: string }}
 */
export function loadS3ConfigFromEnv(env = process.env) {
  const missing = REQUIRED.filter((key) => !env[key]);
  if (missing.length > 0) {
    throw new Error(
      `Configuração de storage incompleta: variáveis de ambiente ausentes: ${missing.join(', ')}. ` +
        'Defina-as via .env local (execução manual) ou como Secrets no Fly.io (produção) antes de usar o storage-client.'
    );
  }

  return {
    endpoint: env.S3_ENDPOINT,
    region: env.S3_REGION,
    bucket: env.S3_BUCKET,
    accessKeyId: env.S3_ACCESS_KEY_ID,
    secretAccessKey: env.S3_SECRET_ACCESS_KEY,
    // Opcional, default false (virtual-hosted-style: https://bucket.endpoint/key).
    // Exposto via env só como válvula de escape caso a execução real (Etapa 2)
    // mostre que o Tigris precisa de path-style para este bucket — sem isso,
    // a única forma de mudar seria editar código.
    forcePathStyle: env.S3_FORCE_PATH_STYLE === 'true',
  };
}
