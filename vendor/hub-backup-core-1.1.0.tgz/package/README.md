# @hub/backup-core

Orquestração de backup/restore da Plataforma HUB. Conhece "backup" (estratégias, manifestos, retenção) — não conhece Tigris, Fly.io ou o SDK da AWS.

## Escopo desta Sprint (1)

Implementado:

- `BackupService` — orquestra `runBackup()` / `restoreOnBoot()` / `buildManifest()` compondo uma estratégia injetada com um `IStorageProvider` injetado.
- Contratos `IContinuousBackupStrategy` (Litestream) e `ISnapshotBackupStrategy` (JSON/uploads).
- Value objects de domínio: `BackupResult`, `RestoreResult`, `SnapshotManifest`, `RestoreManifest`, `RetentionPolicy` (contrato fixado, `evaluate()` deferido).
- `ConfigLoader` — leitura de variáveis de ambiente de conexão com o storage.
- `HealthCheck` — compõe `storageProvider.health()` com idade do último backup.

**Não implementado nesta Sprint** (propositalmente): nenhuma estratégia concreta, nenhum agendador, nenhum endpoint HTTP de disparo, nenhuma integração com aplicação real, nenhum algoritmo de retenção executável. Ver `docs/BackupCore.md`.

## Atualização — Sprint 2

`FileSnapshotStrategy` (implementa `ISnapshotBackupStrategy`) foi implementada — cobre fontes de arquivo único (ex.: JSON de configuração). `IContinuousBackupStrategy` (SQLite/Litestream) continua sem implementação concreta — fora do escopo desta Sprint. Ver `docs/OperationsGuide.md` para uso via `npm run backup:test` / `npm run restore:test`.

## Dependências

Referencia `@hub/storage-client` apenas via anotação JSDoc (`import('@hub/storage-client').IStorageProvider`) para tooling/IDE — **nenhum arquivo deste pacote importa `@hub/storage-client` em runtime**. `BackupService` recebe qualquer objeto que implemente o formato de `IStorageProvider` (duck typing), nunca constrói um provider concreto internamente.
