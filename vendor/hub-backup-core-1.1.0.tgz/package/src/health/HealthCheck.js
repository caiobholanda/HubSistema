/**
 * Compõe o health() do storage-client (conectividade/autenticação/latência)
 * com o sinal específico de backup (idade do último backup por fonte, a
 * partir de um SnapshotManifest). Não sabe nada sobre SQLite, JSON ou
 * Litestream — só interpreta o manifesto e delega a checagem de storage.
 */
export class HealthCheck {
  /**
   * @param {{ storageProvider: import('@hub/storage-client').IStorageProvider, maxAgeMinutes?: number }} deps
   */
  constructor({ storageProvider, maxAgeMinutes = 60 }) {
    this.storageProvider = storageProvider;
    this.maxAgeMinutes = maxAgeMinutes;
  }

  /**
   * @param {import('../domain/SnapshotManifest.js').SnapshotManifest} [manifest]
   */
  async check(manifest) {
    const storage = await this.storageProvider.health();
    const thresholdMs = this.maxAgeMinutes * 60_000;
    const sources = manifest?.sources ?? [];
    const staleSources = sources.filter((s) => s.ageMs == null || s.ageMs > thresholdMs);

    return {
      healthy: storage.healthy && staleSources.length === 0,
      storage,
      staleSources: staleSources.map((s) => s.sourceName),
      checkedAt: new Date().toISOString(),
    };
  }
}
