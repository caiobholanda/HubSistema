import { NotImplementedError } from '../_shared/NotImplementedError.js';

/**
 * Contrato para fontes de execução única (batch): arquivos JSON e árvores de
 * upload. Diferente de IContinuousBackupStrategy: não tem ciclo de vida
 * start/stop, é chamada sob demanda (por um disparo externo, fora do escopo
 * desta Sprint — ver docs/BackupCore.md).
 *
 * `JsonSnapshotStrategy` e `FileTreeSnapshotStrategy` da V1 do ADR-010 foram
 * unificadas em uma única `FileSnapshotStrategy` na V2 (um JSON é uma árvore
 * de arquivos com um único nó) — mas nenhuma implementação concreta é criada
 * nesta Sprint, apenas o contrato.
 *
 * @interface
 */
export class ISnapshotBackupStrategy {
  /**
   * @param {object} sourceConfig
   * @param {import('@hub/storage-client').IStorageProvider} storageProvider
   * @returns {Promise<'restored'|'skipped'|'not-found'>}
   */
  async restoreOnBoot(sourceConfig, storageProvider) {
    throw new NotImplementedError('restoreOnBoot');
  }

  /**
   * @param {object} sourceConfig
   * @param {import('@hub/storage-client').IStorageProvider} storageProvider
   * @returns {Promise<{ sizeBytes?: number, checksum?: string, objectKey?: string }>}
   */
  async runBackup(sourceConfig, storageProvider) {
    throw new NotImplementedError('runBackup');
  }

  /**
   * @param {object} sourceConfig
   * @param {import('@hub/storage-client').IStorageProvider} storageProvider
   * @returns {Promise<{ timestamp: Date|null, ageMs: number|null }>}
   */
  async lastBackupInfo(sourceConfig, storageProvider) {
    throw new NotImplementedError('lastBackupInfo');
  }
}
