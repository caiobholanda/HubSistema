import { createReadStream, createWriteStream } from 'node:fs';
import { mkdir, rm, rename, stat, access, readdir, readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { createGzip, createGunzip } from 'node:zlib';
import { Readable, Transform, compose } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import path from 'node:path';
import { mapWithConcurrency } from '../_shared/concurrency.js';
import { GenerationManifest } from '../domain/GenerationManifest.js';

/**
 * Implementação concreta de ISnapshotBackupStrategy para fontes de arquivo
 * (JSON de configuração/estado) e, desde a Sprint 4.3, de DIRETÓRIO inteiro
 * preservando a estrutura relativa (ex.: `uploads/` do Help Desk — ADR-010 V2
 * unificou os dois num só conceito: um arquivo é uma árvore com um nó).
 *
 * O modo é detectado automaticamente via `stat(sourceConfig.path)` — não
 * exige um campo `type` declarado, e não quebra nenhum `sourceConfig` já em
 * uso (Sprint 1-4.1 sempre apontaram para arquivo).
 *
 * MODO ARQUIVO (inalterado desde a Sprint 4.1): um único objeto
 * `.snapshot.gz` + sidecar `.sha256`, streaming real (leitura, gzip e
 * checksum incrementais via `compose()`), restore com escrita em arquivo
 * temporário e `rename()` atômico só após checksum validado.
 *
 * MODO DIRETÓRIO (Sprint 4.3): cada geração de backup grava um objeto por
 * arquivo (`.../{generationId}/files/{relativePath}.gz`, streaming) mais um
 * `manifest.json` (`.../{generationId}/manifest.json`) com generationId,
 * createdAt, lista completa de arquivos (cada um com checksum SHA-256
 * individual) e as exclusões detectadas desde a geração anterior. Uploads
 * rodam com paralelismo configurável e limitado (`uploadConcurrency`,
 * default 4) — cada arquivo já é streaming (não bufferiza o conteúdo
 * inteiro), então o custo de memória do lote é limitado a
 * ~concorrência × footprint-por-arquivo, não ao tamanho total do diretório.
 * Esta Sprint NÃO implementa upload incremental (todo arquivo é reenviado a
 * cada geração) — `deletedFiles` no manifesto só registra o que sumiu, como
 * preparação para uma sincronização incremental futura, não a implementa.
 *
 * Não conhece nenhuma aplicação: `sourceConfig.path` é sempre informado por
 * quem chama, nunca hardcoded aqui.
 *
 * VALIDAÇÃO DE CONTEÚDO (Sprint 4.6): `sourceConfig.validateContent`
 * (opcional) — `(content: Buffer) => boolean|Promise<boolean>` — roda em
 * todo restore desta fonte, sempre DEPOIS do checksum e ANTES do `rename`
 * atômico. Promovido do padrão que já existia na integração do Portal HUB
 * (validação `JSON.parse()` antes de promover um restore). No modo
 * diretório, o mesmo validador é aplicado a CADA arquivo da geração — só
 * faz sentido para diretórios de conteúdo homogêneo; para diretórios com
 * tipos de arquivo mistos, prefira deixar de fora e confiar só no checksum.
 */
export class FileSnapshotStrategy {
  /** @param {{ uploadConcurrency?: number }} [options] */
  constructor({ uploadConcurrency = 4 } = {}) {
    this.uploadConcurrency = uploadConcurrency;
  }

  async runBackup(sourceConfig, storageProvider) {
    let sourceStat;
    try {
      sourceStat = await stat(sourceConfig.path);
    } catch (err) {
      throw new Error(`Não foi possível acessar a origem "${sourceConfig.path}": ${err.message}`);
    }
    return sourceStat.isDirectory()
      ? this.runDirectoryBackup(sourceConfig, storageProvider)
      : this.runFileBackup(sourceConfig, storageProvider);
  }

  async runFileBackup(sourceConfig, storageProvider) {
    const objectKey = buildObjectKey(sourceConfig.name, new Date());
    const hashing = createHashingTransform();

    let gz;
    try {
      gz = compose(createReadStream(sourceConfig.path), hashing, createGzip());
    } catch (err) {
      throw new Error(`Não foi possível ler o arquivo de origem "${sourceConfig.path}": ${err.message}`);
    }

    try {
      await storageProvider.upload(objectKey, gz, { sourceName: sourceConfig.name });
    } catch (err) {
      throw new Error(`Não foi possível ler o arquivo de origem "${sourceConfig.path}" ou enviá-lo: ${err.message}`);
    }

    const { checksum, sizeBytes } = hashing.getResult();
    await storageProvider.upload(
      checksumSidecarKey(objectKey),
      Readable.from(Buffer.from(checksum, 'utf8')),
      { sourceName: sourceConfig.name }
    );

    return { sizeBytes, checksum, objectKey };
  }

  /**
   * @param {{name: string, path: string}} sourceConfig
   * @param {import('@hub/storage-client').IStorageProvider} storageProvider
   * @param {{ concurrency?: number }} [options]
   */
  async runDirectoryBackup(sourceConfig, storageProvider, { concurrency = this.uploadConcurrency } = {}) {
    const generationId = buildGenerationId(new Date());

    const files = [];
    for await (const entry of walkDirectory(sourceConfig.path)) {
      files.push(entry);
    }

    const previousGeneration = await findLatestGeneration(sourceConfig, storageProvider);
    const previousManifest = previousGeneration
      ? await downloadManifest(storageProvider, previousGeneration.key)
      : null;

    const fileEntries = await mapWithConcurrency(files, concurrency, ({ absolutePath, relativePath }) =>
      uploadDirectoryFile(storageProvider, sourceConfig.name, generationId, absolutePath, relativePath)
    );

    const currentPaths = new Set(fileEntries.map((entry) => entry.relativePath));
    const deletedFiles = previousManifest
      ? previousManifest.files.map((f) => f.relativePath).filter((p) => !currentPaths.has(p))
      : [];

    const manifest = new GenerationManifest({
      generationId,
      createdAt: new Date(),
      sourceName: sourceConfig.name,
      files: fileEntries,
      deletedFiles,
    });

    const manifestKey = buildManifestKey(sourceConfig.name, generationId);
    const manifestJson = JSON.stringify(manifest);
    const manifestChecksum = createHash('sha256').update(manifestJson).digest('hex');
    await storageProvider.upload(manifestKey, Readable.from(Buffer.from(manifestJson, 'utf8')), {
      sourceName: sourceConfig.name,
      generationId,
    });

    return {
      sizeBytes: manifest.totalSizeBytes,
      checksum: manifestChecksum,
      objectKey: manifestKey,
      generationId,
      fileCount: manifest.fileCount,
      deletedFiles: manifest.deletedFiles,
    };
  }

  async restoreOnBoot(sourceConfig, storageProvider) {
    if (await pathExists(sourceConfig.path)) {
      return 'skipped';
    }

    const [latestFile, latestGeneration] = await Promise.all([
      findLatestSnapshot(sourceConfig, storageProvider),
      findLatestGeneration(sourceConfig, storageProvider),
    ]);

    if (!latestFile && !latestGeneration) return 'not-found';

    if (latestGeneration && (!latestFile || latestGeneration.lastModified > latestFile.lastModified)) {
      const manifest = await downloadManifest(storageProvider, latestGeneration.key);
      await restoreManifestFiles(storageProvider, manifest, sourceConfig.path, this.uploadConcurrency, sourceConfig.validateContent);
      return 'restored';
    }

    await downloadAndWrite(storageProvider, latestFile.key, sourceConfig.path, sourceConfig.validateContent);
    return 'restored';
  }

  /**
   * Restore manual/assistido de fonte em modo ARQUIVO para um destino
   * explícito — nunca sobrescreve `sourceConfig.path`. Para diretórios, ver
   * `restoreGenerationTo()`/`restoreFileFromGeneration()`.
   *
   * @param {{name:string, path:string}} sourceConfig
   * @param {import('@hub/storage-client').IStorageProvider} storageProvider
   * @param {string} destinationPath
   */
  async restoreLatestTo(sourceConfig, storageProvider, destinationPath) {
    if (path.resolve(destinationPath) === path.resolve(sourceConfig.path)) {
      throw new Error(
        'restoreLatestTo() nunca pode gravar no path original da fonte — informe um destino diferente.'
      );
    }

    const latest = await findLatestSnapshot(sourceConfig, storageProvider);
    if (!latest) {
      throw new Error(
        `Nenhum backup encontrado para a fonte "${sourceConfig.name}" (prefixo ${buildPrefix(sourceConfig.name)}).`
      );
    }

    const { checksum, sizeBytes } = await downloadAndWrite(storageProvider, latest.key, destinationPath, sourceConfig.validateContent);
    return { objectKey: latest.key, checksum, sizeBytes, destinationPath };
  }

  /**
   * Restore COMPLETO de uma geração de diretório (Sprint 4.3) — restaura
   * todos os arquivos da geração (a mais recente, ou uma específica via
   * `options.generationId`) preservando a estrutura relativa. Nunca
   * sobrescreve `sourceConfig.path` (mesma guarda de `restoreLatestTo`).
   *
   * @param {{name:string, path:string}} sourceConfig
   * @param {import('@hub/storage-client').IStorageProvider} storageProvider
   * @param {string} destinationDir
   * @param {{ generationId?: string, concurrency?: number }} [options]
   */
  async restoreGenerationTo(sourceConfig, storageProvider, destinationDir, options = {}) {
    if (path.resolve(destinationDir) === path.resolve(sourceConfig.path)) {
      throw new Error(
        'restoreGenerationTo() nunca pode gravar no path original da fonte — informe um destino diferente.'
      );
    }
    const manifest = await resolveGenerationManifest(sourceConfig, storageProvider, options.generationId);
    const concurrency = options.concurrency ?? this.uploadConcurrency;
    await restoreManifestFiles(storageProvider, manifest, destinationDir, concurrency, sourceConfig.validateContent);
    return {
      generationId: manifest.generationId,
      fileCount: manifest.fileCount,
      totalSizeBytes: manifest.totalSizeBytes,
      destinationDir,
    };
  }

  /**
   * Restore SELETIVO de um único arquivo dentro de uma geração de diretório
   * (Sprint 4.3) — não exige restaurar a árvore inteira.
   *
   * @param {{name:string, path:string}} sourceConfig
   * @param {import('@hub/storage-client').IStorageProvider} storageProvider
   * @param {string} relativePath - caminho relativo do arquivo dentro da geração, ex.: "sub/dir/arquivo.txt"
   * @param {string} destinationPath
   * @param {{ generationId?: string }} [options]
   */
  async restoreFileFromGeneration(sourceConfig, storageProvider, relativePath, destinationPath, options = {}) {
    const manifest = await resolveGenerationManifest(sourceConfig, storageProvider, options.generationId);
    const entry = manifest.findFile(relativePath);
    if (!entry) {
      const wasDeleted = manifest.deletedFiles.includes(relativePath);
      throw new Error(
        wasDeleted
          ? `Arquivo "${relativePath}" foi excluído na geração "${manifest.generationId}" da fonte "${sourceConfig.name}" (não faz mais parte dela).`
          : `Arquivo "${relativePath}" não encontrado na geração "${manifest.generationId}" da fonte "${sourceConfig.name}".`
      );
    }
    const result = await downloadAndWriteChecksummed(
      storageProvider,
      entry.objectKey,
      destinationPath,
      entry.checksum,
      sourceConfig.validateContent
    );
    return { ...result, relativePath, generationId: manifest.generationId };
  }

  async lastBackupInfo(sourceConfig, storageProvider) {
    const [latestFile, latestGeneration] = await Promise.all([
      findLatestSnapshot(sourceConfig, storageProvider),
      findLatestGeneration(sourceConfig, storageProvider),
    ]);
    const candidates = [latestFile, latestGeneration].filter(Boolean);
    if (candidates.length === 0) return { timestamp: null, ageMs: null };
    const latest = candidates.reduce((a, b) => (a.lastModified > b.lastModified ? a : b));
    return { timestamp: latest.lastModified, ageMs: Date.now() - latest.lastModified.getTime() };
  }
}

function buildPrefix(sourceName) {
  return `backup/snapshots/manual/${sourceName}/`;
}

function isoTimestamp(date) {
  return date.toISOString().replace(/[:.]/g, '-');
}

function buildObjectKey(sourceName, timestamp) {
  return `${buildPrefix(sourceName)}${isoTimestamp(timestamp)}.snapshot.gz`;
}

function checksumSidecarKey(objectKey) {
  return `${objectKey}.sha256`;
}

function buildGenerationId(timestamp) {
  return isoTimestamp(timestamp);
}

function buildGenerationPrefix(sourceName, generationId) {
  return `${buildPrefix(sourceName)}${generationId}/`;
}

function buildManifestKey(sourceName, generationId) {
  return `${buildGenerationPrefix(sourceName, generationId)}manifest.json`;
}

function buildFileObjectKey(sourceName, generationId, relativePath) {
  return `${buildGenerationPrefix(sourceName, generationId)}files/${relativePath}.gz`;
}

/**
 * Transform "pass-through" que calcula SHA-256 e tamanho total dos bytes
 * que passam por ela, sem alterá-los — usada como um estágio no meio de um
 * pipeline de streams (`compose`/`pipeline`), nunca como consumidor único
 * (evita o clássico bug de "dois consumidores" de um mesmo Readable).
 */
function createHashingTransform() {
  const hasher = createHash('sha256');
  let sizeBytes = 0;
  let finalChecksum = null;
  const transform = new Transform({
    transform(chunk, _enc, callback) {
      hasher.update(chunk);
      sizeBytes += chunk.length;
      callback(null, chunk);
    },
    flush(callback) {
      finalChecksum = hasher.digest('hex');
      callback();
    },
  });
  transform.getResult = () => {
    if (finalChecksum === null) {
      throw new Error('createHashingTransform: getResult() chamado antes do stream terminar');
    }
    return { checksum: finalChecksum, sizeBytes };
  };
  return transform;
}

async function pathExists(targetPath) {
  try {
    await access(targetPath);
    return true;
  } catch {
    return false;
  }
}

async function findLatestSnapshot(sourceConfig, storageProvider) {
  const prefix = buildPrefix(sourceConfig.name);
  let latest = null;
  for await (const obj of storageProvider.list(prefix)) {
    if (!obj.key.endsWith('.snapshot.gz')) continue; // ignora sidecars .sha256 e conteúdo de gerações de diretório
    if (!latest || obj.lastModified > latest.lastModified) latest = obj;
  }
  return latest;
}

async function findLatestGeneration(sourceConfig, storageProvider) {
  const prefix = buildPrefix(sourceConfig.name);
  let latest = null;
  for await (const obj of storageProvider.list(prefix)) {
    if (!obj.key.endsWith('/manifest.json')) continue;
    if (!latest || obj.lastModified > latest.lastModified) latest = obj;
  }
  if (!latest) return null;
  const remainder = latest.key.slice(prefix.length);
  const generationId = remainder.slice(0, remainder.length - '/manifest.json'.length);
  return { key: latest.key, lastModified: latest.lastModified, generationId };
}

async function resolveGenerationManifest(sourceConfig, storageProvider, generationId) {
  if (generationId) {
    const manifestKey = buildManifestKey(sourceConfig.name, generationId);
    try {
      return await downloadManifest(storageProvider, manifestKey);
    } catch (err) {
      throw new Error(
        `Geração "${generationId}" não encontrada para a fonte "${sourceConfig.name}": ${err.message}`
      );
    }
  }
  const latest = await findLatestGeneration(sourceConfig, storageProvider);
  if (!latest) {
    throw new Error(
      `Nenhuma geração de diretório encontrada para a fonte "${sourceConfig.name}" (prefixo ${buildPrefix(sourceConfig.name)}).`
    );
  }
  return downloadManifest(storageProvider, latest.key);
}

async function downloadManifest(storageProvider, manifestKey) {
  const stream = await storageProvider.download(manifestKey);
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  const raw = JSON.parse(Buffer.concat(chunks).toString('utf8'));
  return GenerationManifest.fromJSON(raw);
}

/**
 * Varre um diretório recursivamente, preservando a estrutura relativa.
 * `relativePath` é sempre construído com "/" (nunca `path.sep`), para que a
 * chave do objeto no bucket seja portável entre sistemas operacionais.
 * Symlinks são deliberadamente ignorados — evita loop infinito e a
 * ambiguidade de "o que significa fazer backup de um link".
 */
async function* walkDirectory(rootDir, currentAbsolute = rootDir, currentRelative = '') {
  const entries = await readdir(currentAbsolute, { withFileTypes: true });
  for (const entry of entries) {
    if (entry.isSymbolicLink()) continue;
    const relativePath = currentRelative ? `${currentRelative}/${entry.name}` : entry.name;
    const absolutePath = path.join(currentAbsolute, entry.name);
    if (entry.isDirectory()) {
      yield* walkDirectory(rootDir, absolutePath, relativePath);
    } else if (entry.isFile()) {
      yield { absolutePath, relativePath };
    }
  }
}

async function uploadDirectoryFile(storageProvider, sourceName, generationId, absolutePath, relativePath) {
  const hashing = createHashingTransform();
  let gz;
  try {
    gz = compose(createReadStream(absolutePath), hashing, createGzip());
  } catch (err) {
    throw new Error(`Não foi possível ler o arquivo "${relativePath}" da fonte "${sourceName}": ${err.message}`);
  }
  const objectKey = buildFileObjectKey(sourceName, generationId, relativePath);
  try {
    await storageProvider.upload(objectKey, gz, { sourceName, generationId, relativePath });
  } catch (err) {
    throw new Error(`Falha ao enviar o arquivo "${relativePath}" da fonte "${sourceName}": ${err.message}`);
  }
  const { checksum, sizeBytes } = hashing.getResult();
  return { relativePath, sizeBytes, checksum, objectKey };
}

async function restoreManifestFiles(storageProvider, manifest, destinationDir, concurrency, validateContent) {
  await mapWithConcurrency(manifest.files, concurrency, (entry) => {
    const destinationPath = path.join(destinationDir, ...entry.relativePath.split('/'));
    return downloadAndWriteChecksummed(storageProvider, entry.objectKey, destinationPath, entry.checksum, validateContent);
  });
}

/**
 * Baixa, descomprime e valida um objeto em streaming, sem bufferizar o
 * conteúdo descomprimido inteiro em memória DURANTE O DOWNLOAD. Escreve
 * primeiro num arquivo temporário; só promove (`rename` atômico) para
 * `destinationPath` depois do checksum bater — nunca deixa conteúdo não
 * verificado no destino real, mesmo se o processo for interrompido no meio.
 *
 * `validateContent` (opcional, Sprint 4.6 — promovido do padrão que já
 * existia na integração do Portal HUB, onde `JSON.parse()` era usado como
 * sanidade extra antes de promover um restore) roda DEPOIS do checksum e
 * ANTES do rename atômico: checksum -> validateContent() -> rename. Ao
 * contrário do checksum (agnóstico de conteúdo, calculado em streaming),
 * `validateContent` é inerentemente ciente do domínio de quem chama — por
 * isso, ao contrário do resto deste pipeline, ele EXIGE ler o arquivo
 * temporário inteiro de volta para um Buffer antes de invocar o callback.
 * Para fontes pequenas (o caso original: um JSON de configuração) isso é
 * desprezível; para arquivos grandes de um diretório, usar com cautela —
 * derrota parcialmente o streaming só para esse arquivo específico.
 *
 * @param {import('@hub/storage-client').IStorageProvider} storageProvider
 * @param {string} objectKey
 * @param {string} destinationPath
 * @param {string} expectedChecksum
 * @param {(content: Buffer) => (boolean|Promise<boolean>)} [validateContent]
 */
async function downloadAndWriteChecksummed(storageProvider, objectKey, destinationPath, expectedChecksum, validateContent) {
  await mkdir(path.dirname(destinationPath), { recursive: true });
  const tempPath = `${destinationPath}.tmp-${process.pid}-${Date.now()}`;

  const hashing = createHashingTransform();
  try {
    const compressedStream = await storageProvider.download(objectKey);
    await pipeline(compressedStream, createGunzip(), hashing, createWriteStream(tempPath));
  } catch (err) {
    await rm(tempPath, { force: true }).catch(() => {});
    throw new Error(`Falha ao restaurar "${objectKey}": ${err.message}`);
  }

  const { checksum: actualChecksum } = hashing.getResult();

  if (actualChecksum !== expectedChecksum) {
    await rm(tempPath, { force: true }).catch(() => {});
    throw new Error(
      `Checksum inválido ao restaurar "${objectKey}": esperado ${expectedChecksum}, obtido ${actualChecksum}. ` +
        'Restore abortado — o arquivo de destino não foi gravado.'
    );
  }

  if (validateContent) {
    await runValidateContent(validateContent, tempPath, objectKey);
  }

  await rename(tempPath, destinationPath);
  const info = await stat(destinationPath);
  return { checksum: actualChecksum, sizeBytes: info.size };
}

async function runValidateContent(validateContent, tempPath, objectKey) {
  let content;
  try {
    content = await readFile(tempPath);
  } catch (err) {
    await rm(tempPath, { force: true }).catch(() => {});
    throw new Error(`Falha ao ler o conteúdo restaurado de "${objectKey}" para validateContent(): ${err.message}`);
  }

  let valid;
  try {
    valid = await validateContent(content);
  } catch (err) {
    await rm(tempPath, { force: true }).catch(() => {});
    throw new Error(
      `validateContent() lançou exceção ao validar "${objectKey}": ${err.message}. ` +
        'Restore abortado — o arquivo de destino não foi gravado.'
    );
  }

  if (!valid) {
    await rm(tempPath, { force: true }).catch(() => {});
    throw new Error(
      `Conteúdo restaurado de "${objectKey}" reprovado por validateContent(). ` +
        'Restore abortado — o arquivo de destino não foi gravado.'
    );
  }
}

/** Modo arquivo: busca o checksum no sidecar `.sha256` e delega para a validação em streaming. */
async function downloadAndWrite(storageProvider, objectKey, destinationPath, validateContent) {
  const expectedChecksum = await downloadSidecarChecksum(storageProvider, objectKey);
  return downloadAndWriteChecksummed(storageProvider, objectKey, destinationPath, expectedChecksum, validateContent);
}

async function downloadSidecarChecksum(storageProvider, objectKey) {
  const checksumStream = await storageProvider.download(checksumSidecarKey(objectKey));
  const chunks = [];
  for await (const chunk of checksumStream) chunks.push(chunk);
  return Buffer.concat(chunks).toString('utf8').trim();
}
