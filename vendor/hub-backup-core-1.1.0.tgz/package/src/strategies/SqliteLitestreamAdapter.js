import { spawn as defaultSpawn, execFile as defaultExecFile } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdtemp, writeFile, rm, access } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';

/**
 * Implementação concreta de IContinuousBackupStrategy para fontes SQLite via
 * Litestream (processo externo, binário Go — não faz parte do runtime Node).
 *
 * Inversão de supervisão em relação ao setup atual do Help Desk: hoje é o
 * litestream que supervisiona o Node (`litestream replicate -exec "node
 * server.js"`); este adapter assume o modelo oposto exigido por
 * IContinuousBackupStrategy — é o Node (via BackupService) quem chama
 * `start()`/`stop()` e o litestream vira um processo filho supervisionado
 * por nós. Reconciliar isso com o `litestream.yml`/`start.sh` reais do
 * Help Desk é trabalho de integração (Sprint 4A, ainda pausada) — fora do
 * escopo desta Sprint, que só entrega o adapter dentro do hub-sdk.
 *
 * Credenciais: obtidas via `storageProvider.getRawConnectionConfig()` (API
 * interna — ver ADR-011 e RawConnectionConfig). O arquivo de config YAML
 * gerado para o litestream NUNCA contém o valor real do segredo — apenas os
 * placeholders `${LITESTREAM_ACCESS_KEY_ID}`/`${LITESTREAM_SECRET_ACCESS_KEY}`,
 * que o próprio binário litestream expande a partir do ambiente do processo
 * filho. Os valores reais só existem em memória (neste processo) e no
 * ambiente do processo filho — nunca em disco, nunca em log, nunca em
 * exception. Isso é defesa em profundidade: mesmo que o arquivo de config
 * temporário vaze (ex.: sobra em disco, entra num bundle de suporte), ele
 * não contém o segredo.
 */
export class SqliteLitestreamAdapter {
  /**
   * @param {{ spawnFn?: typeof defaultSpawn, execFileFn?: typeof defaultExecFile, stopTimeoutMs?: number }} [deps]
   *   Injeção de dependência das chamadas ao SO — permite testar o adapter
   *   inteiro sem depender do binário `litestream` estar instalado.
   */
  constructor({ spawnFn = defaultSpawn, execFileFn = defaultExecFile, stopTimeoutMs = 10_000 } = {}) {
    this._spawn = spawnFn;
    this._execFile = promisify(execFileFn);
    this._stopTimeoutMs = stopTimeoutMs;
    this.childProcess = null;
    this._activeConfigPath = null;
  }

  /**
   * Verifica se o binário `litestream` existe no PATH, sem tentar iniciar
   * nenhum processo de replicação. Deve ser chamado (e checado) antes de
   * `start()`/`restoreOnBoot()` — ambos chamam isto internamente e falham
   * com uma mensagem clara em vez de deixar o SO estourar um ENOENT difuso.
   * @returns {Promise<{available: boolean, version: string|null, error: string|null}>}
   */
  async checkBinaryAvailable() {
    try {
      const { stdout } = await this._execFile('litestream', ['version']);
      return { available: true, version: parseVersion(stdout), error: null };
    } catch (err) {
      if (err?.code === 'ENOENT') {
        return {
          available: false,
          version: null,
          error: 'binário "litestream" não encontrado no PATH deste processo',
        };
      }
      return { available: false, version: null, error: err.message };
    }
  }

  /**
   * Diagnóstico completo para observabilidade/suporte operacional — nunca
   * inclui nenhuma credencial no retorno (nem sequer os campos mascarados
   * de RawConnectionConfig; a checagem de bucket usa apenas
   * `storageProvider.health()`/`list()`, que já não expõem segredo).
   *
   * @param {{name: string, path: string}} sourceConfig
   * @param {import('@hub/storage-client').IStorageProvider} storageProvider
   */
  async diagnostics(sourceConfig, storageProvider) {
    const checkedAt = new Date().toISOString();
    const binary = await this.checkBinaryAvailable();
    const configErrors = validateSourceConfig(sourceConfig);
    const configValid = configErrors.length === 0;

    let bucketAccessible = false;
    let bucketError = null;
    try {
      const health = await storageProvider.health();
      bucketAccessible = health.healthy;
      bucketError = health.healthy ? null : (health.error ?? 'desconhecido');
    } catch (err) {
      bucketError = err.message;
    }

    let replicaExists = null;
    let replicaError = null;
    if (bucketAccessible && configValid) {
      try {
        replicaExists = await replicaHasObjects(storageProvider, buildReplicaPrefix(sourceConfig.name));
      } catch (err) {
        replicaError = err.message;
      }
    }

    return {
      checkedAt,
      binaryAvailable: binary.available,
      version: binary.version,
      binaryError: binary.error,
      configValid,
      configErrors,
      bucketAccessible,
      bucketError,
      replicaExists,
      replicaError,
    };
  }

  /**
   * @param {{name: string, path: string}} sourceConfig
   * @param {import('@hub/storage-client').IStorageProvider} storageProvider
   */
  async start(sourceConfig, storageProvider) {
    if (this.childProcess) {
      throw new Error('SqliteLitestreamAdapter.start() já está em execução — chame stop() antes de reiniciar.');
    }
    const configErrors = validateSourceConfig(sourceConfig);
    if (configErrors.length > 0) {
      throw new Error(`sourceConfig inválido para SqliteLitestreamAdapter: ${configErrors.join('; ')}`);
    }

    const binary = await this.checkBinaryAvailable();
    if (!binary.available) {
      throw new Error(`Não é possível iniciar a replicação: ${binary.error}`);
    }

    const rawConfig = storageProvider.getRawConnectionConfig();
    const configPath = await writeLitestreamConfig(sourceConfig, rawConfig);

    const child = this._spawn('litestream', ['replicate', '-config', configPath], {
      env: buildChildEnv(rawConfig),
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    this.childProcess = child;
    this._activeConfigPath = configPath;

    // Se o processo morrer sozinho (crash, config inválida detectada só em
    // runtime pelo litestream), não deixamos o estado do adapter mentir
    // dizendo que ainda há replicação ativa.
    child.once('exit', () => {
      if (this.childProcess === child) this.childProcess = null;
    });
  }

  /** @returns {Promise<void>} */
  async stop() {
    const child = this.childProcess;
    const configPath = this._activeConfigPath;
    this.childProcess = null;
    this._activeConfigPath = null;

    if (child) {
      await terminateChild(child, this._stopTimeoutMs);
    }
    if (configPath) {
      await rm(configPath, { force: true }).catch(() => {});
    }
  }

  /**
   * @param {{name: string, path: string}} sourceConfig
   * @param {import('@hub/storage-client').IStorageProvider} storageProvider
   * @returns {Promise<'restored'|'skipped'|'not-found'>}
   */
  async restoreOnBoot(sourceConfig, storageProvider) {
    if (await fileExists(sourceConfig.path)) {
      return 'skipped';
    }

    const replicaPrefix = buildReplicaPrefix(sourceConfig.name);
    const hasReplica = await replicaHasObjects(storageProvider, replicaPrefix);
    if (!hasReplica) {
      return 'not-found';
    }

    const binary = await this.checkBinaryAvailable();
    if (!binary.available) {
      throw new Error(
        `Réplica encontrada para "${sourceConfig.name}", mas não é possível restaurar: ${binary.error}`
      );
    }

    const rawConfig = storageProvider.getRawConnectionConfig();
    const configPath = await writeLitestreamConfig(sourceConfig, rawConfig);
    try {
      await this._execFile('litestream', ['restore', '-config', configPath, sourceConfig.path], {
        env: buildChildEnv(rawConfig),
      });
    } catch (err) {
      throw new Error(`Falha ao restaurar "${sourceConfig.name}" via litestream: ${err.message}`);
    } finally {
      await rm(configPath, { force: true }).catch(() => {});
    }
    return 'restored';
  }

  /**
   * Aproximação, não a semântica exata de "generation" do litestream: usa o
   * timestamp de modificação mais recente entre os objetos da réplica no
   * bucket (segmentos WAL/snapshot que o litestream já escreveu), não o
   * metadado interno de generation/checkpoint do litestream (que exigiria
   * rodar `litestream generations -config ...` por chamada, mais caro e mais
   * frágil por depender do binário estar disponível). Documentado como
   * aproximação deliberada — spike de precisão total fica para uma Sprint
   * futura, se a operação exigir.
   *
   * @param {{name: string, path: string}} sourceConfig
   * @param {import('@hub/storage-client').IStorageProvider} storageProvider
   * @returns {Promise<{ timestamp: Date|null, ageMs: number|null }>}
   */
  async lastBackupInfo(sourceConfig, storageProvider) {
    const prefix = buildReplicaPrefix(sourceConfig.name);
    let latest = null;
    for await (const obj of storageProvider.list(prefix)) {
      if (!latest || obj.lastModified > latest.lastModified) latest = obj;
    }
    if (!latest) return { timestamp: null, ageMs: null };
    return { timestamp: latest.lastModified, ageMs: Date.now() - latest.lastModified.getTime() };
  }
}

function buildReplicaPrefix(sourceName) {
  return `backup/litestream/${sourceName}/`;
}

function validateSourceConfig(sourceConfig) {
  const errors = [];
  if (!sourceConfig?.name || typeof sourceConfig.name !== 'string') {
    errors.push('sourceConfig.name ausente ou inválido');
  }
  if (!sourceConfig?.path || typeof sourceConfig.path !== 'string') {
    errors.push('sourceConfig.path ausente ou inválido');
  }
  return errors;
}

async function fileExists(filePath) {
  try {
    await access(filePath);
    return true;
  } catch {
    return false;
  }
}

async function replicaHasObjects(storageProvider, prefix) {
  for await (const _obj of storageProvider.list(prefix)) {
    return true;
  }
  return false;
}

function parseVersion(stdout) {
  const text = String(stdout ?? '').trim();
  const match = text.match(/v?\d+\.\d+\.\d+\S*/);
  return match ? match[0] : text || null;
}

/**
 * Gera o YAML de config do litestream num arquivo temporário. Contém apenas
 * placeholders de env var para as credenciais — nunca o valor real (ver nota
 * de segurança no topo do arquivo).
 */
async function writeLitestreamConfig(sourceConfig, rawConfig) {
  const dir = await mkdtemp(path.join(tmpdir(), 'hub-sdk-litestream-'));
  const configPath = path.join(dir, 'litestream.yml');
  const yaml = buildConfigYaml(sourceConfig, rawConfig);
  await writeFile(configPath, yaml, 'utf8');
  return configPath;
}

function buildConfigYaml(sourceConfig, rawConfig) {
  const lines = [
    'dbs:',
    `  - path: ${yamlString(sourceConfig.path)}`,
    '    replicas:',
    '      - type: s3',
    `        bucket: ${yamlString(rawConfig.bucket)}`,
    `        path: ${yamlString(`backup/litestream/${sourceConfig.name}`)}`,
    `        region: ${yamlString(rawConfig.region)}`,
    `        force-path-style: ${rawConfig.forcePathStyle ? 'true' : 'false'}`,
    // Placeholders — expandidos pelo próprio litestream a partir do ambiente
    // do processo filho, nunca escritos aqui como valor literal.
    '        access-key-id: ${LITESTREAM_ACCESS_KEY_ID}',
    '        secret-access-key: ${LITESTREAM_SECRET_ACCESS_KEY}',
  ];
  if (rawConfig.endpoint) {
    lines.splice(4, 0, `        endpoint: ${yamlString(rawConfig.endpoint)}`);
  }
  return lines.join('\n') + '\n';
}

function yamlString(value) {
  return JSON.stringify(String(value));
}

function buildChildEnv(rawConfig) {
  return {
    ...process.env,
    LITESTREAM_ACCESS_KEY_ID: rawConfig.accessKeyId,
    LITESTREAM_SECRET_ACCESS_KEY: rawConfig.secretAccessKey,
  };
}

function terminateChild(child, timeoutMs) {
  return new Promise((resolve) => {
    if (child.exitCode !== null || child.signalCode !== null) {
      resolve();
      return;
    }
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
    }, timeoutMs);
    child.once('exit', () => {
      clearTimeout(timer);
      resolve();
    });
    child.kill('SIGTERM');
  });
}
