import { NotImplementedError } from '../_shared/NotImplementedError.js';

/**
 * Contrato para fontes com replicação contínua (hoje: SQLite via Litestream).
 *
 * Diferente de ISnapshotBackupStrategy: tem ciclo de vida start/stop em vez de
 * uma execução única — Litestream é um processo de replicação de longa
 * duração, não uma tarefa que roda e termina. Separar as duas interfaces
 * evita forçar os dois modelos de execução num único formato (ISP).
 *
 * Implementação concreta: SqliteLitestreamAdapter (Sprint 4.2).
 *
 * @interface
 */
export class IContinuousBackupStrategy {
  /**
   * @param {object} sourceConfig
   * @param {import('@hub/storage-client').IStorageProvider} storageProvider
   * @returns {Promise<void>}
   */
  async start(sourceConfig, storageProvider) {
    throw new NotImplementedError('start');
  }

  /** @returns {Promise<void>} */
  async stop() {
    throw new NotImplementedError('stop');
  }

  /**
   * @param {object} sourceConfig
   * @param {import('@hub/storage-client').IStorageProvider} storageProvider
   * @returns {Promise<'restored'|'skipped'|'not-found'>}
   */
  async restoreOnBoot(sourceConfig, storageProvider) {
    throw new NotImplementedError('restoreOnBoot');
  }

  /**
   * @param {object} sourceConfig
   * @param {import('@hub/storage-client').IStorageProvider} storageProvider
   * @returns {Promise<{ timestamp: Date|null, ageMs: number|null }>}
   */
  async lastBackupInfo(sourceConfig, storageProvider) {
    throw new NotImplementedError('lastBackupInfo');
  }
}
