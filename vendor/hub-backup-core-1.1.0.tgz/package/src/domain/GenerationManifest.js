/**
 * Manifesto de UMA geração de backup de diretório (Sprint 4.3) — gravado em
 * `backup/snapshots/manual/{sourceName}/{generationId}/manifest.json`. Não
 * confundir com `SnapshotManifest` (status agregado de todas as fontes de um
 * app, `status/manifest.json` — ADR-010 V2 §Monitoramento): este é o
 * inventário completo de uma única execução de backup de diretório,
 * necessário para restore seletivo de arquivo e para detectar exclusões
 * entre gerações.
 *
 * Value object imutável, sem I/O — quem lê/grava o JSON é a estratégia.
 */
export class GenerationManifest {
  /**
   * @param {{
   *   generationId: string,
   *   createdAt: Date,
   *   sourceName: string,
   *   files: Array<{ relativePath: string, sizeBytes: number, checksum: string, objectKey: string }>,
   *   deletedFiles?: string[],
   * }} params
   */
  constructor({ generationId, createdAt, sourceName, files, deletedFiles = [] }) {
    this.generationId = generationId;
    this.createdAt = createdAt;
    this.sourceName = sourceName;
    this.files = files;
    // Arquivos presentes na geração anterior e ausentes nesta — apenas
    // registro para auditoria/futura sincronização incremental. Esta Sprint
    // não implementa upload incremental (sempre reenvia todos os arquivos);
    // ver nota em FileSnapshotStrategy.runDirectoryBackup().
    this.deletedFiles = deletedFiles;
    Object.freeze(this.files);
    Object.freeze(this.deletedFiles);
    Object.freeze(this);
  }

  get fileCount() {
    return this.files.length;
  }

  get totalSizeBytes() {
    return this.files.reduce((sum, file) => sum + file.sizeBytes, 0);
  }

  findFile(relativePath) {
    return this.files.find((file) => file.relativePath === relativePath) ?? null;
  }

  toJSON() {
    return {
      generationId: this.generationId,
      createdAt: this.createdAt.toISOString(),
      sourceName: this.sourceName,
      fileCount: this.fileCount,
      totalSizeBytes: this.totalSizeBytes,
      files: this.files,
      deletedFiles: this.deletedFiles,
    };
  }

  static fromJSON(raw) {
    return new GenerationManifest({
      generationId: raw.generationId,
      createdAt: new Date(raw.createdAt),
      sourceName: raw.sourceName,
      files: raw.files,
      deletedFiles: raw.deletedFiles ?? [],
    });
  }
}
