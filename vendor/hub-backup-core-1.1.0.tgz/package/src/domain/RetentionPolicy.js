/**
 * Política de retenção "avô-pai-filho" (ADR-010 V2). Objeto de domínio puro:
 * `evaluate()` não faz nenhuma chamada de I/O — recebe descritores de
 * snapshots existentes e devolve quais manter/expirar. A exclusão real é
 * responsabilidade de quem orquestra (fora do escopo desta Sprint).
 *
 * O algoritmo de `evaluate()` não é implementado nesta Sprint — ele depende
 * de decisões que só fazem sentido quando a retenção for de fato executada
 * (Sprint futura, junto da separação de credencial de escrita/deleção do
 * Modelo IAM). Implementar agora seria adivinhar um contrato sem uso real
 * ainda — o contrato (assinatura, construtor) já fica fixado.
 */
export class RetentionPolicy {
  constructor({ hourly = 0, daily = 0, monthly = 0 } = {}) {
    this.hourly = hourly;
    this.daily = daily;
    this.monthly = monthly;
    Object.freeze(this);
  }

  /**
   * @param {Array<{ key: string, granularity: 'hourly'|'daily'|'monthly', createdAt: Date }>} existingSnapshots
   * @param {Date} [now]
   * @returns {{ keep: string[], expire: string[] }}
   */
  evaluate(existingSnapshots, now = new Date()) {
    throw new Error(
      'RetentionPolicy.evaluate() ainda não implementado — ver docs/BackupCore.md (deferido para a Sprint de retenção).'
    );
  }
}
