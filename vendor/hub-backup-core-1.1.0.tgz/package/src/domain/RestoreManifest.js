/**
 * Registro de auditoria de uma operação de restore — trilha exigida pela
 * NT-018 §7/§9 e pelo Modelo IAM do ADR-010 V2 (quem, quando, de qual ponto
 * no tempo). Gravado em `status/history/` a cada restore, automático ou
 * manual.
 */
export class RestoreManifest {
  constructor({ app, source, restoredFrom, operator, executedAt, mode, success }) {
    this.app = app;
    this.source = source;
    this.restoredFrom = restoredFrom;
    this.operator = operator; // 'auto-boot' | identificador do operador humano
    this.executedAt = executedAt;
    this.mode = mode; // 'automatic' | 'manual'
    this.success = success;
  }

  toJSON() {
    return {
      app: this.app,
      source: this.source,
      restoredFrom: this.restoredFrom,
      operator: this.operator,
      executedAt: this.executedAt.toISOString(),
      mode: this.mode,
      success: this.success,
    };
  }
}
