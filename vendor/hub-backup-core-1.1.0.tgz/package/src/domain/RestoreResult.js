/**
 * Value object imutável: resultado de uma operação de restore (automática ou
 * manual) de uma fonte.
 */
export class RestoreResult {
  constructor({ sourceName, mode, restoredFrom, success, skipped = false, error = null }) {
    this.sourceName = sourceName;
    this.mode = mode; // 'automatic' | 'manual'
    this.restoredFrom = restoredFrom ?? null; // identificador de timestamp/geração
    this.success = success;
    this.skipped = skipped;
    this.error = error;
    Object.freeze(this);
  }

  toJSON() {
    return {
      sourceName: this.sourceName,
      mode: this.mode,
      restoredFrom: this.restoredFrom,
      success: this.success,
      skipped: this.skipped,
      error: this.error,
    };
  }
}
