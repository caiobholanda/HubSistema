/**
 * Manifesto de status agregado de uma aplicação — o que é gravado em
 * `status/manifest.json` no bucket (ADR-010 V2). Reúne o estado de todas as
 * fontes configuradas para consumo pelo health check e por auditoria.
 */
export class SnapshotManifest {
  constructor({ app, generatedAt, sources }) {
    this.app = app;
    this.generatedAt = generatedAt;
    this.sources = sources; // Array<{ sourceName, lastBackupAt, ageMs }>
  }

  toJSON() {
    return {
      app: this.app,
      generatedAt: this.generatedAt.toISOString(),
      sources: this.sources,
    };
  }

  static fromJSON(raw) {
    return new SnapshotManifest({
      app: raw.app,
      generatedAt: new Date(raw.generatedAt),
      sources: raw.sources,
    });
  }
}
