/**
 * Value object imutável: resultado de uma execução de backup de uma fonte.
 * Sem identidade própria — definido inteiramente pelos seus dados (DDD).
 */
export class BackupResult {
  constructor({ sourceName, strategyType, success, startedAt, finishedAt, sizeBytes, checksum, objectKey, error }) {
    this.sourceName = sourceName;
    this.strategyType = strategyType; // 'sqlite' | 'json' | 'uploads'
    this.success = success;
    this.startedAt = startedAt;
    this.finishedAt = finishedAt;
    this.durationMs = startedAt && finishedAt ? finishedAt.getTime() - startedAt.getTime() : null;
    this.sizeBytes = sizeBytes ?? null;
    this.checksum = checksum ?? null;
    this.objectKey = objectKey ?? null;
    this.error = error ?? null;
    Object.freeze(this);
  }

  toJSON() {
    return {
      sourceName: this.sourceName,
      strategyType: this.strategyType,
      success: this.success,
      startedAt: this.startedAt?.toISOString() ?? null,
      finishedAt: this.finishedAt?.toISOString() ?? null,
      durationMs: this.durationMs,
      sizeBytes: this.sizeBytes,
      checksum: this.checksum,
      objectKey: this.objectKey,
      error: this.error,
    };
  }
}
