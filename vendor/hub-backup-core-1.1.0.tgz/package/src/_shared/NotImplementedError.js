/**
 * Erro local do backup-core — deliberadamente não reaproveita a classe
 * homônima de @hub/storage-client, para que backup-core não precise de
 * nenhum `import` em runtime desse pacote (a referência ao contrato
 * IStorageProvider vive só em anotações JSDoc). Isso é o que garante
 * inversão de dependência de verdade, não apenas nominal.
 */
export class NotImplementedError extends Error {
  constructor(method) {
    super(`${method}() não implementado por esta estratégia`);
    this.name = 'NotImplementedError';
  }
}
