/**
 * Pool de concorrência simples — no máximo `limit` execuções de `worker` em
 * andamento ao mesmo tempo, sem depender de nenhuma lib externa. Usado pelo
 * backup/restore de diretório (Sprint 4.3) para limitar uploads/downloads
 * simultâneos: cada arquivo já é transmitido em streaming (Sprint 4.1), então
 * o consumo de memória do lote inteiro fica limitado a
 * ~`limit` × footprint-de-streaming-por-arquivo, não ao número total de
 * arquivos nem ao tamanho total do diretório.
 *
 * Preserva a ordem dos resultados (resultados[i] corresponde a items[i]),
 * mesmo que as execuções terminem fora de ordem.
 *
 * @template T, R
 * @param {T[]} items
 * @param {number} limit
 * @param {(item: T, index: number) => Promise<R>} worker
 * @returns {Promise<R[]>}
 */
export async function mapWithConcurrency(items, limit, worker) {
  if (items.length === 0) return [];
  const safeLimit = Math.max(1, Math.min(limit, items.length));
  const results = new Array(items.length);
  let nextIndex = 0;

  async function runLane() {
    while (true) {
      const current = nextIndex++;
      if (current >= items.length) return;
      results[current] = await worker(items[current], current);
    }
  }

  await Promise.all(Array.from({ length: safeLimit }, runLane));
  return results;
}
