/**
 * Coalescência de disparos de backup em rajada — TOTALMENTE OPCIONAL, não
 * exigido por `BackupService` nem por nenhuma estratégia. Promovido ao
 * hub-sdk na Sprint 4.6 a partir de um padrão que já existia, isolado, na
 * integração do Portal HUB (`agendarBackup()`, aws4fetch) — ver auditoria
 * comparativa e revisão arquitetural da Sprint 5. Generalizado aqui para
 * qualquer aplicação com escrita frequente, sem repetir a lógica.
 *
 * Semântica deliberada — THROTTLE, não debounce-com-reset: a primeira
 * chamada a `notifyChange()` agenda uma execução em `windowMs`; chamadas
 * adicionais durante essa janela não estendem o prazo, apenas "pegam
 * carona" na mesma execução já agendada. Isso garante um limite superior
 * previsível de atraso (nunca mais que `windowMs` após a primeira mudança
 * de uma rajada), evitando starvation sob escrita contínua — a mesma
 * escolha já validada em produção pela implementação original.
 *
 * "Última escrita vence" não depende de nenhuma lógica de captura de
 * estado aqui: `trigger` é responsabilidade de quem instancia (tipicamente
 * `() => backupService.runBackup(sourceConfig)`), e `runBackup()` sempre lê
 * o estado atual da fonte no momento em que roda — não no momento em que
 * foi agendado. `BackupScheduler` não sabe nem precisa saber disso; só
 * agenda e executa.
 */
export class BackupScheduler {
  /**
   * @param {{
   *   trigger: () => Promise<unknown>,
   *   windowMs?: number,
   *   onError?: (error: Error) => void,
   * }} deps
   */
  constructor({ trigger, windowMs = 5000, onError } = {}) {
    if (typeof trigger !== 'function') {
      throw new Error(
        'BackupScheduler requer "trigger": uma função que executa o backup ' +
          '(ex.: () => backupService.runBackup(sourceConfig)).'
      );
    }
    this.trigger = trigger;
    this.windowMs = windowMs;
    this.onError = onError;
    this._timer = null;
  }

  /**
   * Notifica uma mudança que deveria eventualmente disparar um backup. Não
   * bloqueia, não retorna uma Promise do backup em si — é fire-and-forget
   * por design, para ser chamável de qualquer ponto de escrita síncrono
   * (ex.: dentro de um `writeData()`) sem transformá-lo em async.
   */
  notifyChange() {
    if (this._timer) return; // já agendado nesta janela — não reseta o prazo
    this._timer = setTimeout(() => {
      this._timer = null;
      this._run();
    }, this.windowMs);
    // Não mantém o processo vivo só por causa deste timer — coerente com o
    // padrão já usado no restante do hub-sdk (nunca é o SDK quem decide o
    // ciclo de vida do processo da aplicação).
    if (this._timer.unref) this._timer.unref();
  }

  /**
   * Executa o backup AGORA, cancelando qualquer execução agendada pendente
   * (para não disparar duas vezes em seguida). Usado tipicamente no
   * shutdown (`SIGTERM`/`SIGINT`), sempre dispara — mesmo sem nenhuma
   * mudança pendente — para garantir uma última tentativa de captura do
   * estado atual antes do processo terminar.
   *
   * @param {number} [timeoutMs] - se informado, não aguarda além deste
   *   prazo (o backup pode continuar rodando em segundo plano, mas
   *   `flush()` retorna de qualquer forma — protege um shutdown de travar
   *   esperando uma rede lenta indefinidamente).
   */
  async flush(timeoutMs) {
    if (this._timer) {
      clearTimeout(this._timer);
      this._timer = null;
    }
    const run = this._run();
    if (timeoutMs == null) {
      await run;
      return;
    }
    await Promise.race([run, delay(timeoutMs)]);
  }

  async _run() {
    try {
      await this.trigger();
    } catch (error) {
      if (this.onError) this.onError(error);
    }
  }
}

function delay(ms) {
  return new Promise((resolve) => {
    const t = setTimeout(resolve, ms);
    if (t.unref) t.unref();
  });
}
