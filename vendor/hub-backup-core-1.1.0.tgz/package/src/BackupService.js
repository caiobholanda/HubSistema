import { BackupResult } from './domain/BackupResult.js';
import { RestoreResult } from './domain/RestoreResult.js';
import { SnapshotManifest } from './domain/SnapshotManifest.js';

/**
 * Orquestra backup/restore compondo uma estratégia (IContinuousBackupStrategy
 * ou ISnapshotBackupStrategy) com um provider de armazenamento
 * (IStorageProvider), ambos injetados no construtor.
 *
 * Não conhece SQLite, JSON, Litestream, S3, Tigris — apenas os contratos
 * recebidos. Isso é o que torna esta classe testável com fakes/mocks e
 * reaproveitável por qualquer combinação futura de estratégia + provider.
 *
 * Não agenda nada, não expõe endpoint HTTP e não sabe nada sobre Fly.io ou
 * GitHub Actions — quem dispara `runBackup()`/`restoreOnBoot()` é decisão de
 * uma Sprint futura (ver docs/BackupCore.md).
 */
export class BackupService {
  /**
   * @param {{
   *   strategy: import('./strategies/IContinuousBackupStrategy.js').IContinuousBackupStrategy
   *            | import('./strategies/ISnapshotBackupStrategy.js').ISnapshotBackupStrategy,
   *   storageProvider: import('@hub/storage-client').IStorageProvider,
   *   appName: string,
   * }} deps
   */
  constructor({ strategy, storageProvider, appName }) {
    this.strategy = strategy;
    this.storageProvider = storageProvider;
    this.appName = appName;
  }

  /**
   * @param {object} sourceConfig
   * @returns {Promise<BackupResult>}
   */
  async runBackup(sourceConfig) {
    const startedAt = new Date();
    try {
      const outcome = await this.strategy.runBackup(sourceConfig, this.storageProvider);
      return new BackupResult({
        sourceName: sourceConfig.name,
        strategyType: sourceConfig.type,
        success: true,
        startedAt,
        finishedAt: new Date(),
        sizeBytes: outcome?.sizeBytes,
        checksum: outcome?.checksum,
        objectKey: outcome?.objectKey,
      });
    } catch (error) {
      return new BackupResult({
        sourceName: sourceConfig.name,
        strategyType: sourceConfig.type,
        success: false,
        startedAt,
        finishedAt: new Date(),
        error: error.message,
      });
    }
  }

  /**
   * @param {object} sourceConfig
   * @returns {Promise<RestoreResult>}
   */
  async restoreOnBoot(sourceConfig) {
    try {
      const outcome = await this.strategy.restoreOnBoot(sourceConfig, this.storageProvider);
      return new RestoreResult({
        sourceName: sourceConfig.name,
        mode: 'automatic',
        restoredFrom: outcome === 'restored' ? 'latest' : null,
        success: outcome !== 'not-found',
        skipped: outcome === 'skipped',
      });
    } catch (error) {
      return new RestoreResult({
        sourceName: sourceConfig.name,
        mode: 'automatic',
        restoredFrom: null,
        success: false,
        error: error.message,
      });
    }
  }

  /**
   * @param {object} sourceConfig
   */
  async currentStatus(sourceConfig) {
    const info = await this.strategy.lastBackupInfo(sourceConfig, this.storageProvider);
    return { sourceName: sourceConfig.name, lastBackupAt: info.timestamp, ageMs: info.ageMs };
  }

  /**
   * @param {object[]} sourceConfigs
   * @returns {Promise<SnapshotManifest>}
   */
  async buildManifest(sourceConfigs) {
    const sources = await Promise.all(sourceConfigs.map((sc) => this.currentStatus(sc)));
    return new SnapshotManifest({ app: this.appName, generatedAt: new Date(), sources });
  }

  /**
   * Promovido ao hub-sdk na Sprint 4.6 a partir de um padrão que já existia,
   * isolado, na integração do Portal HUB (a trava `backupInseguro` do
   * aws4fetch) — ver auditoria comparativa e revisão arquitetural da
   * Sprint 5. Diferente de `BackupScheduler` (otimização de taxa,
   * opcional), isto protege uma invariante de segurança de dado: NÃO
   * altera o contrato público de `restoreOnBoot()` — usa exclusivamente os
   * campos já existentes em `RestoreResult`.
   *
   * O risco que isto evita: se o dado local estava ausente (volume novo/
   * reprovisionado) e a tentativa de restaurar do backup remoto falhou de
   * verdade (rede, 5xx, corrupção — não "simplesmente não existe backup
   * ainda"), habilitar backup contínuo a partir daqui é perigoso — a
   * primeira escrita local (sobre um estado vazio/seed) sobrescreveria um
   * backup remoto que pode estar perfeitamente bom, só temporariamente
   * inacessível.
   *
   * A distinção crucial já está em `RestoreResult.error`: populado só
   * quando `restoreOnBoot()` de fato lançou uma exceção (falha real),
   * nunca no caso de "nenhum backup encontrado ainda" (`success: false`
   * mas `error: null` — app legitimamente nova, sem nada para restaurar).
   * Por isso a regra é sobre `error`, não sobre `success`.
   *
   * @param {import('./domain/RestoreResult.js').RestoreResult} restoreResult
   * @returns {boolean}
   */
  static isSafeToEnableContinuousBackup(restoreResult) {
    if (!restoreResult || typeof restoreResult !== 'object') {
      throw new Error(
        'isSafeToEnableContinuousBackup() requer um RestoreResult (ou objeto com o mesmo formato) — ' +
          'chame restoreOnBoot() primeiro e passe o resultado.'
      );
    }
    return restoreResult.error == null;
  }
}
