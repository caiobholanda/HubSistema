/**
 * Carrega a configuração de CONEXÃO com o storage a partir de variáveis de
 * ambiente. Não carrega "o que fazer backup" (isso é o `backup.config.json`
 * declarativo de cada app, com a lista de `sources` — fora do escopo desta
 * Sprint, pois depende de integrar uma aplicação real).
 *
 * Função pura: recebe `env` como parâmetro (default `process.env`) em vez de
 * ler `process.env` internamente, para ser testável com um objeto fake sem
 * depender ou mutar variáveis de ambiente reais.
 */

const REQUIRED_WHEN_ENABLED = ['BACKUP_PROVIDER', 'BACKUP_BUCKET', 'BACKUP_ACCESS_KEY', 'BACKUP_SECRET_KEY'];

/**
 * @param {NodeJS.ProcessEnv} [env]
 * @returns {{ enabled: boolean } & Partial<{
 *   provider: string, bucket: string, endpoint: string|undefined, region: string,
 *   accessKeyId: string, secretAccessKey: string, retentionDays: number,
 *   maxRetries: number, timeoutMs: number,
 * }>}
 */
export function loadBackupConfig(env = process.env) {
  if (env.BACKUP_ENABLED === 'false') {
    return { enabled: false };
  }

  const missing = REQUIRED_WHEN_ENABLED.filter((key) => !env[key]);
  if (missing.length > 0) {
    throw new Error(`Configuração de backup incompleta: variáveis ausentes: ${missing.join(', ')}`);
  }

  return {
    enabled: true,
    provider: env.BACKUP_PROVIDER, // 'tigris' | 'r2' | 'aws-s3'
    bucket: env.BACKUP_BUCKET,
    endpoint: env.BACKUP_ENDPOINT, // opcional para presets com endpoint default (ex.: tigris)
    region: env.BACKUP_REGION,
    accessKeyId: env.BACKUP_ACCESS_KEY,
    secretAccessKey: env.BACKUP_SECRET_KEY,
    retentionDays: toInt(env.BACKUP_RETENTION_DAYS, 30),
    maxRetries: toInt(env.BACKUP_MAX_RETRIES, 3),
    timeoutMs: toInt(env.BACKUP_TIMEOUT, 10_000),
  };
}

function toInt(value, fallback) {
  const parsed = Number.parseInt(value ?? '', 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}
